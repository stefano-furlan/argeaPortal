package com.argea.argeaportal.database;

import org.springframework.data.repository.CrudRepository;

public interface ClienteArgeaRepository extends CrudRepository<ClienteArgea, Integer> {

}
