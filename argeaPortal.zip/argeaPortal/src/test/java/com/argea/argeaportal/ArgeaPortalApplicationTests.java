package com.argea.argeaportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArgeaPortalApplicationTests {

    @Test
    void contextLoads() {
    }

}
